package org.kurento.tutorial.n_one2manycall;

/**
 * Created by jingbiaowang on 2015/8/31.
 */
public class RoomBean {

    private String sessionId;
    private String name;

    public String getSessionId() {
        return sessionId;
    }

    public void setSessionId(String sessionId) {
        this.sessionId = sessionId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
